#include "build_random.h"
#include <string>

// 这个函数确保随机数据被包含在二进制文件中
const char* getBuildID() {
    static const char* buildID = BUILD_RANDOM;
    return buildID;
}

// 每次构建时间戳也会变化
extern "C" {
    const char* getBuildDate() {
        return __DATE__ " " __TIME__;
    }
}